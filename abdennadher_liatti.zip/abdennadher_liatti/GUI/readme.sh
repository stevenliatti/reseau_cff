#!/bin/bash

#Pour lancer le programme reseau_cff_GUI, exécuter la commande suivante :
java -jar reseau_cff_GUI.jar

# Tous les fichiers nécessaires (suisse.txt, ville.xml, etc.) sont inclus dans le .jar

