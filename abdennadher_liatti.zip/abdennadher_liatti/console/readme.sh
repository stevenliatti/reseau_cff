#!/bin/bash
#Pour compiler le programme :
javac Main.java

#Ensuite pour le lancer :
java Main

# Le fichier villes.xml se trouve dans le dossier core
